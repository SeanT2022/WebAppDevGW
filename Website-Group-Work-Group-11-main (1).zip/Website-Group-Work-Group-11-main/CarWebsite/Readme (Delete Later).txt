1). Save The folder into C:\xampp\htdocs.
2). Turn on Apache on XAMPP Control Pannel.
3). Type http://localhost/CarWebsite/ into URl of Web Browser.